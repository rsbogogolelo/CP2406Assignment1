/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */

public class Main
{
    public static void main(String[] args)
    {
        GameFunction gameFunction = new GameFunction();
        gameFunction.StartGame();
    }
}
/*
THIS IS THE MAIN JAVA CLASS TO RUN THE ENTIRE GAME
DONE BY REUBEN BOGOGOLELO
 */