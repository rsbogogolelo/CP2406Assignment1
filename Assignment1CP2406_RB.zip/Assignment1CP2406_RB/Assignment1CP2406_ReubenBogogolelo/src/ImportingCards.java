/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */
public class ImportingCards{
    /**
     * This is a the layout for every single fundamental card that supertrump cards will have its
     * own class containing constructors. In addition, there is a capacity to print the estimations of a card
     * (see StatisticalShowingOfData). Again, it contains capacities to change the class string values into numeric values.
     * DONE BY : REUBEN BOGOGOLELO
     */


    public ImportingCards(String callingName, double HardnessInput, double SpecificGravityInput, String CrystalValueInput,
                          String CrystalAbundanceInput, String EconomicValueInput)
    {
        NameOfTheMineral = callingName;
        HardnessOfTheMineral = HardnessInput;
        if (HardnessInput < 1 || HardnessInput > 10)
        {
            System.out.println("As per Moh's Scale, Hardness must be between 1 and 10.");
            System.out.println("Hardness is reset to 1 ");
            HardnessOfTheMineral = 1;
        }
        MineralSpecificGravity = SpecificGravityInput;
        MineralCleavage = CleavingToCleavage(CrystalValueInput);
        MineralCrystalAbundance = SparseToAbundance(CrystalAbundanceInput);
        MineralEconomicValue = CostToEconomicValue(EconomicValueInput);
    }
    public void StatisticalShowingOfData()

    {
        String CleavageOFtheMineral,CleavageAbundance,EconomicValues;
        CleavageOFtheMineral = CleavageToCleave(MineralCleavage);
        CleavageAbundance = AbundanceToRarity(MineralCrystalAbundance);
        EconomicValues = EconomicValueToPrice(MineralEconomicValue);
        System.out.println("The Display of " + NameOfTheMineral + " are as follows: Hardness is " + HardnessOfTheMineral +
                ", specific gravity is " + MineralSpecificGravity + ", MineralCleavage is " +
                CleavageOFtheMineral + ", crystal abundance is " + CleavageAbundance + ", and economic value is " + EconomicValues + ".");
    }
    public byte CleavingToCleavage(String Cleaving)
    {
        switch(Cleaving) {
            case "none":
                MineralCleavage = 0;
                break;
            case "poor/none":
                MineralCleavage = 1;
                break;
            case "1 poor":
                MineralCleavage = 2;
                break;
            case "2 poor":
                MineralCleavage = 3;
                break;
            case "1 good":
                MineralCleavage = 4;
                break;
            case "1 good, 1 poor":
                MineralCleavage = 5;
                break;
            case "2 good":
                MineralCleavage = 6;
                break;
            case "3 good":
                MineralCleavage = 7;
                break;
            case "1 perfect":
                MineralCleavage = 8;
                break;
            case "1 perfect, 1 good":
                MineralCleavage = 9;
                break;
            case "1 perfect, 2 good":
                MineralCleavage = 10;
                break;
            case "2 perfect, 1 good":
                MineralCleavage = 11;
                break;
            case "3 perfect":
                MineralCleavage = 12;
                break;
            case "4 perfect":
                MineralCleavage = 13;
                break;
            case "6 perfect":
                MineralCleavage = 14;
                break;
            default:
                System.out.println("UNCLEAR CLEAVAGE AND CLEAVAGE RESET TO ZERO BY ITSELF.");
                MineralCleavage = 0;
                break;
        }
        return MineralCleavage;
    }

    public String CleavageToCleave(byte cleavage)
    {
        String inputCleave="";
        switch(cleavage)
        {
            case 0:
                inputCleave = "none";
                break;
            case 1:
                inputCleave = "poor/none";
                break;
            case 2:
                inputCleave = "1 poor";
                break;
            case 3:
                inputCleave = "2 poor";
                break;
            case 4:
                inputCleave = "1 good";
                break;
            case 5:
                inputCleave = "1 good, 1 poor";
                break;
            case 6:
                inputCleave = "2 good";
                break;
            case 7:
                inputCleave = "3 good";
                break;
            case 8:
                inputCleave = "1 perfect";
                break;
            case 9:
                inputCleave = "1 perfect, 1 good";
                break;
            case 10:
                inputCleave = "1 perfect, 2 good";
                break;
            case 11:
                inputCleave = "2 perfect, 1 good";
                break;
            case 12:
                inputCleave = "3 perfect";
                break;
            case 13:
                inputCleave = "4 perfect";
                break;
            case 14:
                inputCleave = "6 perfect";
                break;
            default:
                System.out.println("ERROR IN MINERALCLEAVAGE VALUE AND CLEAVE RESET TO ZERO BY ITSELF.");

                break;
        }
        return inputCleave;
    }
    public byte SparseToAbundance(String rarityOfTheMineral)
    {
        byte CrystalAbundanceInput=7;
        switch(rarityOfTheMineral)
        {
            case "ultratrace":
                CrystalAbundanceInput = 0;
                break;
            case "trace":
                CrystalAbundanceInput = 1;
                break;
            case "low":
                CrystalAbundanceInput = 2;
                break;
            case "moderate":
                CrystalAbundanceInput = 3;
                break;
            case "high":
                CrystalAbundanceInput = 4;
                break;
            case "very high":
                break;
            default:
                System.out.println("INVALID CRYSTAL ABUNDANCE VALUE AND ITS RESET TO ULTRATRACE BY ITSELF");
                CrystalAbundanceInput = 0;
                break;
        }
        return CrystalAbundanceInput;
    }

    public String AbundanceToRarity(byte crystalAbundance)
    {
        String rarity = "";
        switch(crystalAbundance)
        {
            case 0:
                rarity = "ultratrace";
                break;
            case 1:
                rarity = "trace";
                break;
            case 2:
                rarity = "low";
                break;
            case 3:
                rarity = "moderate";
                break;
            case 4:
                rarity = "high";
                break;
            case 5:
                rarity = "very high";
                break;
            default:
                System.out.println("UNCLEAR CRYSTAL ABUNDANCE AND ITS RESET TO ULTRATRACE BY ITSELF .");
                rarity = "ultratrace";
                break;
        }
        return rarity;
    }

    public byte CostToEconomicValue(String CostOfTheMineral)
    {
        byte EconomicalValueOFTheMineral;
        switch(CostOfTheMineral)
        {
            case "trivial":
                EconomicalValueOFTheMineral = 0;
                break;
            case "low":
                EconomicalValueOFTheMineral = 1;
                break;
            case "moderate":
                EconomicalValueOFTheMineral = 2;
                break;
            case "high":
                EconomicalValueOFTheMineral = 3;
                break;
            case "very high":
                EconomicalValueOFTheMineral = 4;
                break;
            case "I'm rich!":
                EconomicalValueOFTheMineral = 5;
                break;
            default:
                System.out.println("INVALID ECONOMICAL VALUE AND ITS RESET TO TRIVIAL BY ITSELF.");
                EconomicalValueOFTheMineral = 0;
                break;
        }
        return EconomicalValueOFTheMineral;
    }
    public String EconomicValueToPrice(byte MineralEconomicalValue)

    {
        String price = "";
        switch(MineralEconomicalValue)
        {
            case 0:
                price = "trivial";
                break;
            case 1:
                price = "low";
                break;
            case 2:
                price = "moderate";
                break;
            case 3:
                price = "high";
                break;
            case 4:
                price = "very high";
                break;
            case 5:
                price = "I'm rich!";
                break;
            default:
                System.out.println("INVALID ECONOMICAL VALUE AND ITS REST TO TRIVIAL BY ITSELF");
                price = "trivial";
        }
        return price;
    }

    public double getMineralHardness()
    {
        return HardnessOfTheMineral;
    }

    public double getGravity()
    {
        return MineralSpecificGravity;
    }

    public byte getAbundance()
    {
        return MineralCrystalAbundance;
    }

    public byte getValue()
    {
        return MineralEconomicValue;
    }

    public byte getMineralCleavage()
    {
        return MineralCleavage;
    }

    String NameOfTheMineral;
    double HardnessOfTheMineral,MineralSpecificGravity;
    byte MineralCrystalAbundance, MineralEconomicValue, MineralCleavage;
    public ImportingCards()
    {
        NameOfTheMineral = "Unnamed_Mineral";
        HardnessOfTheMineral = 0;
        MineralSpecificGravity = 0;
        MineralCleavage = 0;
        MineralCrystalAbundance = 0;
        MineralEconomicValue = 0;
    }
}
