/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */
public abstract class CardFunction
{
    public abstract void StatisticalShowingOFData();
    public abstract String InputMineralName();
    public abstract String InputMineralCategory(String current_category);
    public abstract double getNewValue(String current_category);
    public abstract boolean checkIfPlayable(String current_category, double current_value);
}
