/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */
import java.util.*;
public class Player
{
    public Player(int CallingNewNumber, String CallingNewName)
    {
        number = CallingNewNumber;
        name = CallingNewName;
        PlayerHand = new ArrayList<CardFunction>();
        StartPlaying = true;
        WinnerOfGame = false;
    }

    public boolean StartPlaying()
    {
        return StartPlaying;
    }

    public int getPlayerNumber()
    {
        return number;
    }

    public boolean GetWinningStatus()
    {
        return WinnerOfGame;
    }

    public ArrayList<CardFunction> getPlayer()
    {
        return PlayerHand;
    }

    public ArrayList<String> getCardsInHand()
    {
        ArrayList<String> NameOfTheCards = new ArrayList<>();
        for (int i = 0; i < PlayerHand.size(); ++i)
        {
            NameOfTheCards.add(PlayerHand.get(i).InputMineralName());
        }
        return NameOfTheCards;
    }
    //Handles Round Winners and Overall Game winners
    public String getName()
    {
        return name;
    }
    public void changeHand(ArrayList<CardFunction> newhand)
    {
        PlayerHand = newhand;
    }
    public void changePlayStatus(boolean newstatus)

    {
        StartPlaying = newstatus;
    }
    public void changeWinStatus(boolean newstatus)
            //changes WinnerOfGame to the new status
    {
        WinnerOfGame = newstatus;
    }
    public Player()
    {
        number = 1;
        name = "Player 1";
        PlayerHand = new ArrayList<CardFunction>();
        StartPlaying = true;
        WinnerOfGame = false;
    }
    int number;
    String name;
    ArrayList<CardFunction> PlayerHand;
    Boolean StartPlaying, WinnerOfGame;
}
