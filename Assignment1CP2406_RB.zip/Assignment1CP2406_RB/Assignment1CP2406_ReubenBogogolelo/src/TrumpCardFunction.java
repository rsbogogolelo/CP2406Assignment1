/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */

import java.util.Scanner;
public class TrumpCardFunction extends CardFunction

{
    String mineralName, mineralCategory;
    public TrumpCardFunction()
    {
        mineralName = "UNNAMED TRUMP CARD";
        mineralCategory = "YOUR CHOICE";
    }
    public TrumpCardFunction(String newname, String newcategory)
    {
        mineralName = newname;
        if (newcategory.equals("MineralHardness") || newcategory.equals("specific gravity") || newcategory.equals("crystal abundance") || newcategory.equals("economic value") || newcategory.equals("MineralCleavage") || newcategory.equals("your choice"))
        {
            mineralCategory = newcategory;
        }
        else
        {
            System.out.println("The trump you entered was not valid, please enter a valid trump mineralCategory:");
            Scanner scanner = new Scanner(System.in);
            String validcategory = scanner.nextLine();
            this.changeCategory(validcategory);
        }
    }

    public void StatisticalShowingOFData()
    {
        System.out.printf("%20s", mineralName + ":");
        System.out.println(" allows a player to change the playable trump to "+ mineralCategory + ".");
    }
    public void changeName(String newname)
    {
        mineralName = newname;
    }
    public void changeCategory(String newcategory)
    {
        switch(newcategory)
        {
            case "MineralHardness":
                mineralCategory = newcategory;
                break;
            case "specific gravity":
                mineralCategory = newcategory;
                break;
            case "economic value":
                mineralCategory = newcategory;
                break;
            case "crystal abundance":
                mineralCategory = newcategory;
                break;
            case "MineralCleavage":
                mineralCategory = newcategory;
                break;
            default:
                System.out.println("The trump you entered was invalid, please enter a valid trump mineralCategory:");
                Scanner newscanner = new Scanner(System.in);
                this.changeCategory(newscanner.nextLine());
        }
    }

    public String InputMineralName()
    {
        return mineralName;
    }
    public String getMineralCategory()
    {
        return mineralCategory;
    }
    public String InputMineralCategory(String current_category)
    {
        if (mineralCategory.equals("your choice"))
        {
            System.out.println("Which mineralCategory do you want the new playable trump to be?");
            Scanner scanner = new Scanner(System.in);
            String newcategory = scanner.nextLine();
            switch(newcategory.toLowerCase())
            {
                case "MineralHardness":
                    current_category = "MineralHardness";
                    break;
                case "economic value":
                    current_category = "economic value";
                    break;
                case "MineralCleavage":
                    current_category = "MineralCleavage";
                    break;
                case "specific gravity":
                    current_category = "specific gravity";
                    break;
                case "crystal abundance":
                    current_category = "crystal abundance";
                    break;
                default:
                    System.out.println("Your answer was unclear, pick one of the five categories:");
                    System.out.println(" MineralHardness, specific gravity, economic value, crystal abundance, or MineralCleavage");
                    InputMineralCategory(current_category);
            }
        }
        else
        {
            current_category = mineralCategory;
        }
        return current_category;
    }
    public double getNewValue(String current_category)

    {
        return -1;
    }
    public boolean checkIfPlayable(String current_category, double current_value)
    {return true;}
}