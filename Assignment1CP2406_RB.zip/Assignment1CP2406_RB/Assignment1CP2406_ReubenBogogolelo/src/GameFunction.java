/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */
import java.util.*;
import static java.lang.Math.round;
public class GameFunction {
    public GameFunction()
    {
        System.out.println("LET'S PLAY THE MINERAL SUPERTRUMP CARD!");
        int playernumber = AskFromUser();
        Player[] players = new Player[playernumber];
        for (int i = 0; i < playernumber; ++i) {
            int number = i + 1;
            System.out.println("PLEASE ENTER NAME OF THE PLAYER " + number );
            System.out.print(">>>");
            Scanner scanner = new Scanner(System.in);
            String inputname = scanner.nextLine();
            players[i] = new Player(number, inputname);

        }
        Random generator = new Random();
        YourTurn = generator.nextInt(playernumber);
        CurrentCategory = "none";
        CurrentValue = -1;
        CardDeck = initializeDeck();
        ListOFPlayers = players;
        ListOFWinners = new Player[playernumber - 1];
        WinnerNumber = 0;
    }
    public int AskFromUser()
    {
        int returnvalue = 0;
        System.out.println("PLEASE ENTER THE NUMBER OF THE PLAYERS BETWEEN 3 AND 5");
        System.out.print(">>>");
        Scanner scanner = new Scanner(System.in);
        int NoOfPlayers = scanner.nextInt();
        switch (NoOfPlayers) {
            case 3:
                returnvalue = 3;
                break;
            case 4:
                returnvalue = 4;
                break;
            case 5:
                returnvalue = 5;
                break;
            default:
                System.out.println("THAT IS AN INVALID NUMBER , PLEASE ENTER THE NUMBER OF PLAYERS BETWEEN 3 AND 5");
                AskFromUser();
        }
        return returnvalue;
    }
    public ArrayList<CardFunction> initializeDeck()
    {
        ArrayList Deck = new ArrayList();
        Deck.add(new MineralCardFunction("Apatite", 5, 3.2, "2 poor", "low", "high"));
        Deck.add(new MineralCardFunction("Augite", 6.5, 3.6, "2 good", "high", "trivial"));
        Deck.add(new MineralCardFunction("Barite", 3.5, 4.5, "2 perfect, 1 good", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Beryl", 8, 2.9, "1 poor", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Biotite", 3, 3.3, "1 perfect", "moderate", "low"));
        Deck.add(new MineralCardFunction("Calcite", 3, 2.7, "3 perfect", "moderate", "high"));
        Deck.add(new MineralCardFunction("Cassiterite", 7, 7.1, "1 good, 1 poor", "trace", "high"));
        Deck.add(new MineralCardFunction("Chalcopyrite", 4, 4.3, "2 poor", "low", "very high"));
        Deck.add(new MineralCardFunction("Chlorite", 3, 3.3, "1 perfect", "moderate", "low"));
        Deck.add(new MineralCardFunction("Chromite", 5.5, 5.1, "none", "low", "high"));
        Deck.add(new MineralCardFunction("Corundum", 9, 4, "none", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Diamond", 10, 3.5, "4 perfect", "ultratrace", "I'm rich!"));
        Deck.add(new MineralCardFunction("Dolomite", 4, 2.9, "3 perfect", "low", "low"));
        Deck.add(new MineralCardFunction("Epidote", 6.5, 3.5, "1 perfect", "moderate", "trivial"));
        Deck.add(new MineralCardFunction("Fluorite", 4, 3.2, "4 perfect", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Galena", 2.5, 7.6, "3 perfect", "trace", "high"));
        Deck.add(new MineralCardFunction("Garnet", 7.5, 4.3, "none", "moderate", "moderate"));
        Deck.add(new MineralCardFunction("Gibbsite", 3.5, 2.4, "1 perfect", "low", "high"));
        Deck.add(new MineralCardFunction("Glaucophane", 6, 3.2, "2 good", "low", "trivial"));
        Deck.add(new MineralCardFunction("Goethite", 5.5, 4.3, "1 perfect, 1 good", "moderate", "moderate"));
        Deck.add(new MineralCardFunction("Gold", 3, 19.3, "none", "ultratrace", "I'm rich!"));
        Deck.add(new MineralCardFunction("Graphite", 2, 2.2, "1 perfect", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Gypsum", 2, 2.3, "1 perfect, 2 good", "trace", "high"));
        Deck.add(new MineralCardFunction("Halite", 2.5, 2.2, "3 perfect", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Hematite", 6, 5.3, "none", "trace", "high"));
        Deck.add(new MineralCardFunction("Hornblende", 6, 3.5, "2 good", "moderate", "trivial"));
        Deck.add(new MineralCardFunction("Ilmenite", 6, 4.8, "none", "low", "moderate"));
        Deck.add(new MineralCardFunction("Kaolinite", 2.5, 2.7, "1 perfect", "moderate", "high"));
        Deck.add(new MineralCardFunction("Kyanite", 7, 3.7, "1 perfect, 1 good", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Magnesite", 4, 3, "3 perfect", "low", "moderate"));
        Deck.add(new MineralCardFunction("Magnetite", 6, 5.2, "none", "moderate", "very high"));
        Deck.add(new MineralCardFunction("Molybdenite", 1.5, 4.7, "1 perfect", "trace", "high"));
        Deck.add(new MineralCardFunction("Monazite", 5, 5.3, "1 good, 1 poor", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Muscovite", 3, 2.9, "1 perfect", "moderate", "moderate"));
        Deck.add(new MineralCardFunction("Olivine", 7, 4.4, "2 poor", "high", "low"));
        Deck.add(new MineralCardFunction("Orthoclase", 6.5, 2.6, "1 perfect, 1 good", "high", "moderate"));
        Deck.add(new MineralCardFunction("Orthopyroxene", 6, 3.9, "2 good", "high", "trivial"));
        Deck.add(new MineralCardFunction("Plagioclase", 6.5, 2.8, "1 perfect, 1 good", "very high", "moderate"));
        Deck.add(new MineralCardFunction("Pyrite", 6.5, 5, "2 poor", "low", "moderate"));
        Deck.add(new MineralCardFunction("Pyrrhotite", 4.5, 4.6, "none", "low", "moderate"));
        Deck.add(new MineralCardFunction("Quartz", 7, 2.65, "poor/none", "high", "moderate"));
        Deck.add(new MineralCardFunction("Rutile", 6.5, 4.3, "2 good", "low", "high"));
        Deck.add(new MineralCardFunction("Siderite", 4.5, 4, "3 perfect", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Sillimanite", 7.5, 3.25, "1 perfect, 1 good", "low", "low"));
        Deck.add(new MineralCardFunction("Sphalerite", 4, 4.1, "6 perfect", "trace", "high"));
        Deck.add(new MineralCardFunction("Staurolite", 7, 3.8, "1 good", "trace", "low"));
        Deck.add(new MineralCardFunction("Talc", 1, 2.8, "1 perfect", "low", "moderate"));
        Deck.add(new MineralCardFunction("Titanite", 5.5, 3.6, "3 good", "low", "low"));
        Deck.add(new MineralCardFunction("Topaz", 8, 3.6, "1 perfect", "ultratrace", "low"));
        Deck.add(new MineralCardFunction("Tourmaline", 7.5, 3.2, "2 poor", "trace", "moderate"));
        Deck.add(new MineralCardFunction("Zircon", 7.5, 4.7, "2 poor", "trace", "moderate"));
        Deck.add(new TrumpCardFunction("The Gemmologist", "MineralHardness"));
        Deck.add(new TrumpCardFunction("The Geologist", "your choice"));
        Deck.add(new TrumpCardFunction("The Geophysicist", "specific gravity"));
        Deck.add(new TrumpCardFunction("The Miner", "economic value"));
        Deck.add(new TrumpCardFunction("The Mineralogist", "MineralCleavage"));
        Deck.add(new TrumpCardFunction("The Petrologist", "crystal abundance"));
        return Deck;
    }
    public void displayCurrentCategory() {
        System.out.print(CurrentCategory);
    }
    public void displayCurrentValue() {
        if (CurrentValue == -1) {
            System.out.println("No Value Yet");
        } else {
            switch (CurrentCategory) {
                case "MineralHardness":
                case "specific gravity":
                    System.out.print(CurrentValue);
                    break;
                case "crystal abundance":
                    String rarity = "";
                    int rounded = (int) round(CurrentValue);
                    switch (rounded) {
                        case 0:
                            rarity = "ultratrace";
                            break;
                        case 1:
                            rarity = "trace";
                            break;
                        case 2:
                            rarity = "low";
                            break;
                        case 3:
                            rarity = "moderate";
                            break;
                        case 4:
                            rarity = "high";
                            break;
                        case 5:
                            rarity = "very high";
                            break;
                        default:
                            System.out.println("UNCLEAR CRYSTAL ABUNDANCE AND ITS RESET TO UNLTRATRACE BY ITSELF");
                            rarity = "ultratrace";
                            break;
                    }
                    System.out.print(rarity);
                    break;
                case "economic value":
                    int rounded1 = (int) round(CurrentValue);
                    String Cost = "";
                    switch (rounded1) {
                        case 0:
                            Cost = "trivial";
                            break;
                        case 1:
                            Cost = "low";
                            break;
                        case 2:
                            Cost = "moderate";
                            break;
                        case 3:
                            Cost = "high";
                            break;
                        case 4:
                            Cost = "very high";
                            break;
                        case 5:
                            Cost = "I'm rich!";
                            break;
                        default:
                            System.out.println("UNCLEAR ECONOMIC VALUE AND ITS RESET BY TRIVIAL BY ITSELF");
                            Cost = "trivial";
                    }
                    System.out.print(Cost);
                    break;
                case "MineralCleavage":
                    int rounded3 = (int) round(CurrentValue);
                    String cleave = "";
                    switch (rounded3) {
                        case 0:
                            cleave = "none";
                            break;
                        case 1:
                            cleave = "poor/none";
                            break;
                        case 2:
                            cleave = "1 poor";
                            break;
                        case 3:
                            cleave = "2 poor";
                            break;
                        case 4:
                            cleave = "1 good";
                            break;
                        case 5:
                            cleave = "1 good, 1 poor";
                            break;
                        case 6:
                            cleave = "2 good";
                            break;
                        case 7:
                            cleave = "3 good";
                            break;
                        case 8:
                            cleave = "1 perfect";
                            break;
                        case 9:
                            cleave = "1 perfect, 1 good";
                            break;
                        case 10:
                            cleave = "1 perfect, 2 good";
                            break;
                        case 11:
                            cleave = "2 perfect, 1 good";
                            break;
                        case 12:
                            cleave = "3 perfect";
                            break;
                        case 13:
                            cleave = "4 perfect";
                            break;
                        case 14:
                            cleave = "6 perfect";
                            break;
                        default:
                            System.out.println("ERROR IN MINERAL CLEVAGE VALUE AND ITS RESET TO ZERO BY ITSELF.");
                            break;
                    }
                    System.out.print(cleave);
                    break;
                default:
                    System.out.print(CurrentValue);
                    break;
            }
        }
    }
    public void drawCard(Player player)
    {
        Random generator = new Random();
        CardFunction newdraw = CardDeck.get(generator.nextInt(CardDeck.size()));
        player.getPlayer().add(newdraw);
        CardDeck.remove(newdraw);

    }

    public void dealCards()
    {
        for (int i = 0; i < ListOFPlayers.length; ++i) {
            for (int x = 0; x < 8; ++x) {
                drawCard(ListOFPlayers[i]);
            }
        }
    }
    public void declareCategory()
    {
        System.out.println("WHAT IS YOUR NEW PLAYABLE TRUMP CARD?");
        System.out.print(">>>");
        Scanner scanner = new Scanner(System.in);
        String response = scanner.nextLine();
        switch (response.toLowerCase()) {
            case "hardness":
                CurrentCategory = "hardness";
                break;
            case "economic value":
                CurrentCategory = "economic value";
                break;
            case "cleavage":
                CurrentCategory = "cleavage";
                break;
            case "crystal abundance":
                CurrentCategory = "crystal abundance";
                break;
            case "specific gravity":
                CurrentCategory = "specific gravity";
                break;
            default:
                System.out.println("IT IS AN UNCLEAR ANSWER");
                System.out.println("Please only enter hardness, economic value, cleavage, crystal abundance, or specific gravity.");
                declareCategory();
        }
        CurrentValue = -1;
    }
    public void displayHand(Player player)
    {
        ArrayList<String> cardnames = new ArrayList<String>();
        for (int i = 0; i < player.getPlayer().size(); ++i) {
            cardnames.add(player.getPlayer().get(i).InputMineralName());
        }
        System.out.println(cardnames);
        System.out.println("");
        for (int i = 0; i < player.getPlayer().size(); ++i) {
            player.getPlayer().get(i).StatisticalShowingOFData();
        }
    }
    public ArrayList getPlayersNames(Player player)
    {
        ArrayList<String> cardnames = new ArrayList<String>();
        for (int i = 0; i < player.getPlayer().size(); ++i) {
            cardnames.add(player.getPlayer().get(i).InputMineralName().toLowerCase());
        }
        return cardnames;
    }

    public boolean isSinglePLayer()
    {
        boolean returnvalue = false;
        int passedplayers = 0;
        for (int i = 0; i < ListOFPlayers.length; ++i) {
            if (ListOFPlayers[i].StartPlaying() == false || ListOFPlayers[i].GetWinningStatus() == true) {
                ++passedplayers;
            }
        }
        if (passedplayers >= ListOFPlayers.length - 1) {
            returnvalue = true;
        }
        return returnvalue;
    }

    public void playFirstCardOfRound()
    {
        for (int i = 0; i < ListOFPlayers.length; ++i)           //changes everyone's play status to true
        {
            ListOFPlayers[i].changePlayStatus(true);
        }
        System.out.println("It is " + ListOFPlayers[YourTurn].getName() + "'s turn.");
        System.out.println(ListOFPlayers[YourTurn].getName() + " will start off a new round!");
        displayHand(ListOFPlayers[YourTurn]);
        checkCombo();
        System.out.println("");
        declareCategory();
        playCardNoPass();
    }

    public void playCard()
    {
        checkCombo();
        displayHand(ListOFPlayers[YourTurn]);
        ArrayList<String> lowercardnames = new ArrayList<>();
        for (int i = 0; i < ListOFPlayers[YourTurn].getPlayer().size(); ++i)
        {
            lowercardnames.add(ListOFPlayers[YourTurn].getPlayer().get(i).InputMineralName().toLowerCase());
        }
        System.out.println("WHICH CARD DO YOU WANT TO PLAY? YOU CAN TYPE 'PASS' TO PASS");
        System.out.print(">>>");
        Scanner scanner = new Scanner(System.in);
        String cardname = scanner.nextLine();
        if (!lowercardnames.contains(cardname.toLowerCase()))
        {
            if (cardname.equals("pass"))
            {
                pass();
            } else {
                System.out.println("CANT FIND YOUR CARD IN YOUR CARD!");
                playCard();
            }
        } else
        {
            CardFunction playedcard = new MineralCardFunction();
            for (int i = 0; i < lowercardnames.size(); ++i) {
                if (cardname.toLowerCase().equals(lowercardnames.get(i))) {
                    playedcard = ListOFPlayers[YourTurn].getPlayer().get(i);
                }
            }
            if (playedcard.checkIfPlayable(CurrentCategory, CurrentValue) == false)
            {
                System.out.println("YOU CAN'T PLAY THAT CARD AT THE MOMENT, SINCE IT CARRIES A LOWER VALUE OF THE PREVIOUS CARD PLAYED!.");
                playCard();
            } else {
                CurrentCategory = playedcard.InputMineralCategory(CurrentCategory);
                CurrentValue = playedcard.getNewValue(CurrentCategory);
                ListOFPlayers[YourTurn].getPlayer().remove(playedcard);
            }
        }
    }

    public void playCard(String cardname)
    {
        CardFunction playedcard = new MineralCardFunction();
        for (int i = 0; i < getPlayersNames(ListOFPlayers[YourTurn]).size(); ++i)
        {
            if (cardname.toLowerCase().equals(getPlayersNames(ListOFPlayers[YourTurn]).get(i))) {
                playedcard = ListOFPlayers[YourTurn].getPlayer().get(i);
            }
        }
        if (playedcard.checkIfPlayable(CurrentCategory, CurrentValue) == false)
        {
            System.out.println("YOU CAN'T PLAY THAT CARD AT THE MOMENT, SINCE IT CARRIES A LOWER VALUE OF THE PREVIOUS CARD PLAYED!.");
            askPassOrPlay();
        } else {
            CurrentCategory = playedcard.InputMineralCategory(CurrentCategory);
            CurrentValue = playedcard.getNewValue(CurrentCategory);
            ListOFPlayers[YourTurn].getPlayer().remove(playedcard);
        }
    }
    public void checkCombo()
    {
        if (getPlayersNames(ListOFPlayers[YourTurn]).contains("magnetite") && getPlayersNames(ListOFPlayers[YourTurn]).contains("the geophysicist")) {
            System.out.println("Do you want to play Magnetite and The Geophysicist together to win? Yes or no.");
            Scanner scanner = new Scanner(System.in);
            switch (scanner.next().toLowerCase()) {
                case "yes":
                    playerWins();
                    nextTurn();
                    break;
                case "no":
                    break;
                default:
                    System.out.println("THAT WAS UNCLEAR.");
                    checkCombo();
            }
        }
    }

    public void pass()
    {
        ListOFPlayers[YourTurn].changePlayStatus(false);
        drawCard(ListOFPlayers[YourTurn]);
    }

    public void askPassOrPlay()
    {
        displayCurrentCategory();
        System.out.print(": ");
        displayCurrentValue();
        System.out.println("");
        displayHand(ListOFPlayers[YourTurn]);
        System.out.println("DO YOU WANT TO PASS OR PLAY A CARD??");
        System.out.print(">>>");
        Scanner scanner = new Scanner(System.in);
        String entered = scanner.nextLine();
        if (getPlayersNames(ListOFPlayers[YourTurn]).contains(entered.toLowerCase()) == true) {
            playCard(entered);
        } else {
            switch (entered) {
                case ("pass"):
                    pass();
                    break;
                case ("play"):
                case ("play a card"):
                    playCard();
                    break;
                default:
                    System.out.println("I'm sorry that wasn't clear. You can type play, a card's NameOfTheMineral, or pass.");
                    askPassOrPlay();
            }
        }
    }

    public void play()
    {
        System.out.println("It is " + ListOFPlayers[YourTurn].getName() + "'s turn.");
        askPassOrPlay();
    }

    public void playCardNoPass()
    {
        displayHand(ListOFPlayers[YourTurn]);
        ArrayList<String> lowercardnames = new ArrayList<>();
        for (int i = 0; i < ListOFPlayers[YourTurn].getPlayer().size(); ++i)
        {
            lowercardnames.add(ListOFPlayers[YourTurn].getPlayer().get(i).InputMineralName().toLowerCase());
        }
        System.out.println("WHICH CARD DO YOU WANT TO PLAY?");
        System.out.print(">>>");
        Scanner scanner = new Scanner(System.in);
        String cardname = scanner.next();
        if (!lowercardnames.contains(cardname.toLowerCase()))
        {
            System.out.println("I couldn't find that card in your PlayerHand.");
            playCardNoPass();
        } else
        {
            CardFunction playedcard = new MineralCardFunction();
            for (int i = 0; i < lowercardnames.size(); ++i) {
                if (cardname.toLowerCase().equals(lowercardnames.get(i))) {
                    playedcard = ListOFPlayers[YourTurn].getPlayer().get(i);
                }
            }
            if (playedcard.checkIfPlayable(CurrentCategory, CurrentValue) == false)
            {
                System.out.println("YOU CAN'T PLAY THAT CARD AT THE MOMENT.");
                playCardNoPass();
            } else {
                CurrentCategory = playedcard.InputMineralCategory(CurrentCategory);
                CurrentValue = playedcard.getNewValue(CurrentCategory);
                ListOFPlayers[YourTurn].getPlayer().remove(playedcard);
            }
        }
    }
    public void turn()
    {
        if (isSinglePLayer() == true) {
            playFirstCardOfRound();
            checkForWin();
            nextTurn();
        } else {
            play();
            checkForWin();
            nextTurn();
        }
    }
    public void checkForWin()
    {
        if (ListOFPlayers[YourTurn].getPlayer().size() == 0) {
            playerWins();
        }
    }

    public void playerWins()
    {
        System.out.println(ListOFPlayers[YourTurn].getName() + " wins!");
        ListOFPlayers[YourTurn].changeWinStatus(true);
        ListOFWinners[WinnerNumber] = ListOFPlayers[YourTurn];
        WinnerNumber++;
    }
    public void nextTurn()
    {
        ++YourTurn;
        if (YourTurn >= ListOFPlayers.length) {
            YourTurn = 0;
        }
        if (ListOFPlayers[YourTurn].StartPlaying() == false || ListOFPlayers[YourTurn].GetWinningStatus() == true) {
            nextTurn();
        }
    }
    public void endGame()
    {
        ArrayList finallist = new ArrayList();
        for (int i = 0; i < ListOFWinners.length; ++i) {
            int place = i + 1;
            System.out.println(ListOFWinners[i].getName() + " is number " + place + "!");
            finallist.add(ListOFWinners[i]);
        }
        for (int x = 0; x < ListOFPlayers.length; ++x) {
            if (finallist.contains(ListOFPlayers[x]) == false) {
                System.out.println(ListOFPlayers[x].getName() + " loses!");
            }
        }
        System.out.println("THANK YOU FOR ALL PLAYING!");
    }
    public void StartGame() {
        dealCards();
        playFirstCardOfRound();
        nextTurn();
        while (WinnerNumber < ListOFPlayers.length - 1) {
            turn();
        }
        endGame();
    }
    int YourTurn, WinnerNumber;
    String CurrentCategory;
    double CurrentValue;
    ArrayList<CardFunction> CardDeck;
    Player[] ListOFPlayers, ListOFWinners;
}
