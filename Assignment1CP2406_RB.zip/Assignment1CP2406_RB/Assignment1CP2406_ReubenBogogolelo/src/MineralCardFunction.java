/**
 * Created by Reuben Bogogolelo on 12/09/2017.
 */
import static java.lang.Math.round;
public class MineralCardFunction extends CardFunction
{
    public MineralCardFunction()
    {
        MineralName = "Unnamed_Mineral";
        MineralHardness = 0;
        MineralSpecificGravity = 0;
        MineralCleavage = 0;
        MineralCrystalAbundance = 0;
        MineralEconomicValue = 0;
    }
    public MineralCardFunction(String NewMineralName, double HardnessINput, double InputSpecificGravity,
                               String MineralCleavage, String MineralCrystalAbundance, String MineralEconomicvalue)

    {
        MineralName = NewMineralName;
        MineralHardness = HardnessINput;
        if (HardnessINput < 1 || HardnessINput > 10)
        {
            System.out.println("As per Moh's Scale, Hardness must be between 1 and 10.");
            System.out.println("Hardness is reset to 1.");
            MineralHardness = 1;
        }
        MineralSpecificGravity = InputSpecificGravity;
        this.MineralCleavage = cleaveToCleavage(MineralCleavage);
        this.MineralCrystalAbundance = rarityToAbundance(MineralCrystalAbundance);
        MineralEconomicValue = CostToEconomicValue(MineralEconomicvalue);
    }
    public void StatisticalShowingOFData()
    {
        String CleavageVAlue,CleavageABundance,EconomicalValueS;
        CleavageVAlue = cleavageToCleave(MineralCleavage);
        CleavageABundance = AbundanceToRarity(MineralCrystalAbundance);
        EconomicalValueS = EconomicalValueToCost(MineralEconomicValue);
        System.out.printf("%20s", MineralName + ":");
        System.out.printf("%11s", "MineralHardness:");
        System.out.printf("%4s", MineralHardness);
        System.out.printf("%18s", "specific gravity:");
        System.out.printf("%4s", MineralSpecificGravity);
        System.out.printf("%11s", "MineralCleavage:");
        System.out.printf("%20s", CleavageVAlue);
        System.out.printf("%20s", "crystal abundance:");
        System.out.printf("%10s", CleavageABundance);
        System.out.printf("%18s", "economic value:");
        System.out.printf("%10s", EconomicalValueS);
        System.out.println("");
    }
    public double cleaveToCleavage(String cleave)
    {
        switch(cleave)
        {
            case "none":
                MineralCleavage = 0;
                break;
            case "poor/none":
                MineralCleavage = 1;
                break;
            case "1 poor":
                MineralCleavage = 2;
                break;
            case "2 poor":
                MineralCleavage = 3;
                break;
            case "1 good":
                MineralCleavage = 4;
                break;
            case "1 good, 1 poor":
                MineralCleavage = 5;
                break;
            case "2 good":
                MineralCleavage = 6;
                break;
            case "3 good":
                MineralCleavage = 7;
                break;
            case "1 perfect":
                MineralCleavage = 8;
                break;
            case "1 perfect, 1 good":
                MineralCleavage = 9;
                break;
            case "1 perfect, 2 good":
                MineralCleavage = 10;
                break;
            case "2 perfect, 1 good":
                MineralCleavage = 11;
                break;
            case "3 perfect":
                MineralCleavage = 12;
                break;
            case "4 perfect":
                MineralCleavage = 13;
                break;
            case "6 perfect":
                MineralCleavage = 14;
                break;
            default:
                System.out.println("Cleavage unclear.");
                System.out.println("Cleavage set to none by default.");
                MineralCleavage = 0;
                break;
        }
        return MineralCleavage;
    }

    public String cleavageToCleave(double cleavage)
    {
        int rounded = (int) round(cleavage);
        String cleave="";
        switch(rounded)
        {
            case 0:
                cleave = "none";
                break;
            case 1:
                cleave = "poor/none";
                break;
            case 2:
                cleave = "1 poor";
                break;
            case 3:
                cleave = "2 poor";
                break;
            case 4:
                cleave = "1 good";
                break;
            case 5:
                cleave = "1 good, 1 poor";
                break;
            case 6:
                cleave = "2 good";
                break;
            case 7:
                cleave = "3 good";
                break;
            case 8:
                cleave = "1 perfect";
                break;
            case 9:
                cleave = "1 perfect, 1 good";
                break;
            case 10:
                cleave = "1 perfect, 2 good";
                break;
            case 11:
                cleave = "2 perfect, 1 good";
                break;
            case 12:
                cleave = "3 perfect";
                break;
            case 13:
                cleave = "4 perfect";
                break;
            case 14:
                cleave = "6 perfect";
                break;
            default:
                System.out.println("ERROR IN MINERAL CLEAVAGE VALUE AND RESET TO ZERO BY ITSELF.");
                break;
        }
        return cleave;
    }
    public double rarityToAbundance(String rarity)
    {
        double crystalAbundance=7;
        switch(rarity)
        {
            case "ultratrace":
                crystalAbundance = 0;
                break;
            case "trace":
                crystalAbundance = 1;
                break;
            case "low":
                crystalAbundance = 2;
                break;
            case "moderate":
                crystalAbundance = 3;
                break;
            case "high":
                crystalAbundance = 4;
                break;
            case "very high":
                crystalAbundance = 5;
                break;
            default:
                System.out.println("UNCLEAR CRYSTAL ABUNDANCE AND ITS SET TO ULTRATRACE BY ITSELF.");
                crystalAbundance = 0;
                break;
        }
        return crystalAbundance;
    }
    public String AbundanceToRarity(double CrystalAbundance)
    {
        int rounded = (int) round(CrystalAbundance);
        String rarity = "";
        switch(rounded)
        {
            case 0:
                rarity = "ultratrace";
                break;
            case 1:
                rarity = "trace";
                break;
            case 2:
                rarity = "low";
                break;
            case 3:
                rarity = "moderate";
                break;
            case 4:
                rarity = "high";
                break;
            case 5:
                rarity = "very high";
                break;
            default:
                System.out.println("UNCLEAR CRYSTAL ABUNDANCE AND ITS RESET TO ULTRATRACE BY ITSELF");
                rarity = "ultratrace";
                break;
        }
        return rarity;
    }
    public double CostToEconomicValue(String Cost)
    {
        byte EconomicalValue;
        switch(Cost)
        {
            case "trivial":
                EconomicalValue = 0;
                break;
            case "low":
                EconomicalValue = 1;
                break;
            case "moderate":
                EconomicalValue = 2;
                break;
            case "high":
                EconomicalValue = 3;
                break;
            case "very high":
                EconomicalValue = 4;
                break;
            case "I'm rich!":
                EconomicalValue = 5;
                break;
            default:
                System.out.println("UNCLEAR ECONOMIC VALUE AND RESET TO TRIVIAL BY ITSELF.");
                EconomicalValue = 0;
                break;
        }
        return EconomicalValue;
    }
    public String EconomicalValueToCost(double Economic_Value)
    {
        int rounded = (int) round(Economic_Value);
        String Cost = "";
        switch(rounded)
        {
            case 0:
                Cost = "trivial";
                break;
            case 1:
                Cost = "low";
                break;
            case 2:
                Cost = "moderate";
                break;
            case 3:
                Cost = "high";
                break;
            case 4:
                Cost = "very high";
                break;
            case 5:
                Cost = "I'm rich!";
                break;
            default:
                System.out.println("UNCLEAR ECONOMIC VALUE ABD RESET TO TRIVIAL BY ITSELF.");
                Cost = "trivial";
        }
        return Cost;
    }
    public String InputMineralName()
    {
        return MineralName;
    }
    public double getMineralHardness()
    {
        return MineralHardness;
    }
    public double getGravity()
    {
        return MineralSpecificGravity;
    }
    public double getAbundance()
    {
        return MineralCrystalAbundance;
    }
    public double getValue()
    {
        return MineralEconomicValue;
    }
    public double getMineralCleavage()
    {
        return MineralCleavage;
    }
    public String InputMineralCategory(String current_category)
    {
        return current_category;
    }
    public double getNewValue(String current_category)
    {
        double newvalue = -1;
        switch(current_category)
        {
            case "MineralHardness":
                newvalue = MineralHardness;
                break;
            case "economic value":
                newvalue = MineralEconomicValue;
                break;
            case "specific gravity":
                newvalue = MineralSpecificGravity;
                break;
            case "crystal abundance":
                newvalue = MineralCrystalAbundance;
                break;
            case "MineralCleavage":
                newvalue = MineralCleavage;
                break;
            default:
                System.out.println("YOU HAVE A PROBLEM BECAUSE YOU ENTERED THE WRONG CURRENT CATEGORY IN YOUR CODE SOMEWHERE");
                break;
        }
        if (newvalue==-1)
        {
            System.out.println("YOUR getCurrentValue() HAS SOME PROBLEMS!!!");
        }
        return newvalue;
    }
    public boolean checkIfPlayable(String current_category, double current_value)
    { boolean returns = true;
        if(current_category.equals("MineralHardness"))
        {
            if(getMineralHardness() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("specific gravity"))
        {
            if(getGravity() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("economic value"))
        {
            if(getValue() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("crystal abundance"))
        {
            if(getAbundance() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("MineralCleavage"))
        {
            if(getMineralCleavage() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        return returns;
    }
    String MineralName;
    double MineralHardness, MineralSpecificGravity;
    double MineralCrystalAbundance, MineralEconomicValue, MineralCleavage;
}